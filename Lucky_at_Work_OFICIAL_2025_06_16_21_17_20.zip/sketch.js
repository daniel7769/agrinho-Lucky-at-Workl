// Variáveis globais
let personagem;
let imgFrente, imgCostas, imgEsquerda, imgDireita;
let tela = "inicio";
let imgTelaInicial, imgFazenda, imgInstrucoes;
let posX, posY;
let velocidade = 8;
let inventarioAberto = false;
let inventarioPequenoImg, inventarioAbertoImg;

// Horta
let terrenos = [];
let limiteTerrenos = 5;
let ordemPlantas = ["tomate", "tomate", "cenoura", "repolho", "rabanete"];
let imgTerreno;
let imagensPlantas = {};

function preload() {
  // Personagem
  imgFrente = loadImage("frente.png");
  imgCostas = loadImage("costas.png");
  imgEsquerda = loadImage("esquerda.png");
  imgDireita = loadImage("direita.png");

  // Telas
  imgTelaInicial = loadImage("tela_inicial.png");
  imgFazenda = loadImage("fazenda.png");
  imgInstrucoes = loadImage("instrucoes.png");

  // Inventário
  inventarioPequenoImg = loadImage("inventario_pequeno.png");
  inventarioAbertoImg = loadImage("inventario_aberto.png");

  // Horta e plantas
  imgTerreno = loadImage("horta.png");
  imagensPlantas["tomate"] = loadImage("tomate.png");
  imagensPlantas["cenoura"] = loadImage("cenoura.png");
  imagensPlantas["repolho"] = loadImage("repolho.png");
  imagensPlantas["rabanete"] = loadImage("rabanete.png");
}

function setup() {
  createCanvas(650, 565);
  posX = width / 2;
  posY = height / 2;
  personagem = imgFrente;
}

function draw() {
  background(0);

  if (tela === "inicio") {
    image(imgTelaInicial, 0, 0, width, height);
  } else if (tela === "instrucoes") {
    image(imgInstrucoes, 0, 0, width, height);
  } else if (tela === "fazenda") {
    image(imgFazenda, 0, 0);

    // Terrenos primeiro, depois personagem
    for (let t of terrenos) {
      image(imgTerreno, t.x, t.y, t.largura, t.altura);
    }

    image(personagem, posX, posY, personagem.width * 0.1, personagem.height * 0.1);

    for (let t of terrenos) {
      for (let planta of t.plantas) {
        image(imagensPlantas[planta.tipo], planta.x, planta.y, 20, 20);
      }
    }

    // Inventário
    image(inventarioPequenoImg, width - 70, 10, 60, 60);
    if (inventarioAberto) image(inventarioAbertoImg, 50, 50);
  }
}

function keyPressed() {
  if (tela === "inicio" && keyCode === ENTER) tela = "fazenda";

  if (tela === "fazenda") {
    if (key === 'w' || key === 'W') personagem = imgCostas;
    else if (key === 's' || key === 'S') personagem = imgFrente;
    else if (key === 'a' || key === 'A') personagem = imgEsquerda;
    else if (key === 'd' || key === 'D') personagem = imgDireita;

    // Criar terreno
    if (key === 'e' || key === 'E') {
      if (terrenos.length < limiteTerrenos && corNoChao() === "marrom") {
        let tipo = ordemPlantas[terrenos.length];
        let maxPlantas = tipo === "cenoura" ? 3 : tipo === "repolho" ? 2 : tipo === "rabanete" ? 2 : 3;
        terrenos.push({
          x: posX,
          y: posY,
          largura: 80,
          altura: 80,
          tipo: tipo,
          plantas: [],
          maxPlantas: maxPlantas
        });
      }
    }

    // Colher planta
    if (key === 'q' || key === 'Q') {
      for (let t of terrenos) t.plantas = [];
    }
  }
}

function keyReleased() {
  if (tela === "fazenda") {
    let novoX = posX;
    let novoY = posY;
    if (key === 'w' || key === 'W') novoY -= velocidade;
    else if (key === 's' || key === 'S') novoY += velocidade;
    else if (key === 'a' || key === 'A') novoX -= velocidade;
    else if (key === 'd' || key === 'D') novoX += velocidade;

    if (verificarColisao(novoX, novoY)) {
      posX = novoX;
      posY = novoY;
    }
  }
}

function mousePressed() {
  if (tela === "inicio") {
    if (mouseX >= 590 && mouseX <= 630 && mouseY >= 10 && mouseY <= 50) tela = "instrucoes";
  } else if (tela === "instrucoes") {
    tela = "inicio";
  } else if (tela === "fazenda") {
    let x = mouseX;
    let y = mouseY;
    let invX = width - 70;
    let invY = 10;
    let invW = 60;
    let invH = 60;

    if (x > invX && x < invX + invW && y > invY && y < invY + invH) inventarioAberto = !inventarioAberto;
    else inventarioAberto = false;

    for (let t of terrenos) {
      if (x >= t.x && x <= t.x + t.largura && y >= t.y && y <= t.y + t.altura) {
        if (t.plantas.length < t.maxPlantas) {
          t.plantas.push({ tipo: t.tipo, x: x, y: y });
          break;
        }
      }
    }
  }
}

function verificarColisao(x, y) {
  if (x < 0 || x > width - 30 || y < 0 || y > height - 40) return false;
  if (x > 530 && x < 620 && y > 40 && y < 120) return false;
  if (x > 50 && x < 190 && y > 70 && y < 200) return false;
  if (x > 40 && x < 270 && y > 300 && y < 520) return false;
  return true;
}

function corNoChao() {
  // Função placeholder: sempre retorna "marrom".
  return "marrom";
}
